-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2020 at 07:07 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saide_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(10) UNSIGNED NOT NULL,
  `ISBN_NO` varchar(100) DEFAULT NULL,
  `Book_Title` varchar(200) DEFAULT NULL,
  `Book_Type` int(10) UNSIGNED DEFAULT NULL,
  `Author_Name` varchar(100) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Purchase_Date` date DEFAULT NULL,
  `Edition` varchar(40) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT 0.00,
  `Pages` int(11) DEFAULT NULL,
  `Publisher` varchar(140) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `ISBN_NO`, `Book_Title`, `Book_Type`, `Author_Name`, `Quantity`, `Purchase_Date`, `Edition`, `Price`, `Pages`, `Publisher`) VALUES
(5, '00001', 'Computer Technology', 5, 'Brian Christian', 100, '2015-10-31', '21', '100.00', 230, 'CSE'),
(6, '00002', 'Physics I', 5, 'Gareth James', 100, '2015-10-31', '31', '100.00', 300, 'CSE'),
(7, '00003', 'Structured Programming', 5, 'Tom Griffiths', 100, '2016-10-31', '51', '100.00', 500, 'CSE'),
(8, '00004', 'Database Management System', 5, 'Harold Abelson', 200, '2012-10-31', '100', '200.00', 404, 'CSE'),
(9, '00005', 'Algorithm', 5, 'Gerald Jay Sussman', 200, '2019-10-31', '20', '100.00', 1000, 'CSE'),
(10, '00006', 'Computer Organization & Architecture', 5, 'Gayle Laakmann McDowell', 30, '2017-10-31', '50', '150.00', 500, 'CSE'),
(11, 'LLB1', 'Jurisprudence-1', 6, 'Mike Walsh', 10, '0000-00-00', '25', '200.00', 200, 'LLB'),
(12, 'LLB2', 'Legal System of Bangladesh', 6, 'Atur Gani', 100, '2018-10-31', '25', '150.00', 500, 'LLB'),
(13, 'LLB3', 'Muslim Law-1', 6, 'Abdur Rahim Green', 200, '2019-10-31', '21', '100.00', 300, 'LLB'),
(14, 'English1', 'English for Academic Purposes-I', 7, 'John Bunyan', 50, '2019-10-31', '21', '100.00', 250, 'English'),
(15, 'English2', 'English Fundamentals', 7, 'Daniel Defoe', 30, '2017-09-01', '31', '100.00', 150, 'English'),
(16, 'English3', 'Introduction to English Poetry', 7, 'Jonathan Swift', 50, '2020-11-01', '11', '150.00', 200, 'English'),
(17, 'English Novel - 1', 'Tom Jones', 8, 'Henry Fielding', 20, '2018-11-01', NULL, '0.00', NULL, NULL),
(18, 'English Novel - 2', 'Emma', 8, 'Jane Austen', NULL, '2020-11-01', NULL, '0.00', NULL, NULL),
(19, 'Humayun Ahmed - 1', 'অপেক্ষা', 9, 'Humayun Ahmed', 10, '2020-11-01', NULL, '0.00', NULL, NULL),
(20, 'Humayun Ahmed - 2', 'নন্দিত নরকে', 9, 'Humayun Ahmed', NULL, '2020-11-01', NULL, '0.00', NULL, NULL),
(22, '1234321', 'Computer Technology', 5, NULL, NULL, '2020-11-01', NULL, '0.00', NULL, NULL),
(23, '123321', 'Object Oriented Programming', 5, NULL, NULL, '2020-11-01', NULL, '0.00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `book_issue`
--

CREATE TABLE `book_issue` (
  `id` int(10) UNSIGNED NOT NULL,
  `Member` int(10) UNSIGNED DEFAULT NULL,
  `Number` int(10) UNSIGNED DEFAULT NULL,
  `Book_Number` int(10) UNSIGNED DEFAULT NULL,
  `Book_Title` int(10) UNSIGNED DEFAULT NULL,
  `Issue_Date` date DEFAULT NULL,
  `Return_Date` date DEFAULT NULL,
  `Status` varchar(40) DEFAULT NULL,
  `issue_id` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book_issue`
--

INSERT INTO `book_issue` (`id`, `Member`, `Number`, `Book_Number`, `Book_Title`, `Issue_Date`, `Return_Date`, `Status`, `issue_id`) VALUES
(3, 3, 3, 19, 19, '2020-09-01', '2020-11-01', 'returned', '001'),
(4, 11, 11, 5, 5, '2020-08-01', '2020-09-01', 'issued', '009'),
(5, 6, 6, 11, 11, '2020-06-01', '2020-10-01', NULL, '002'),
(6, 5, 5, 5, 5, '2020-10-01', '2020-11-01', 'returned', '001'),
(7, 9, 9, 5, 5, '2020-09-01', '2020-10-01', 'returned', '007'),
(8, 13, 13, 19, 19, '2020-11-01', '2020-11-01', NULL, 'STD013'),
(9, 4, 4, 22, 22, '2020-10-01', '2020-10-15', 'returned', 'STD004'),
(10, 6, 6, 5, 5, '2020-10-01', '2020-11-01', 'returned', 'STD002');

-- --------------------------------------------------------

--
-- Stand-in structure for view `iqramul`
-- (See below for the actual view)
--
CREATE TABLE `iqramul` (
`memberID` varchar(20)
,`passMD5` varchar(40)
,`email` varchar(100)
,`signupDate` date
,`groupID` int(10) unsigned
,`isBanned` tinyint(4)
,`isApproved` tinyint(4)
,`custom1` text
,`custom2` text
,`custom3` text
,`custom4` text
,`comments` text
,`pass_reset_key` varchar(100)
,`pass_reset_expiry` int(10) unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `magazines`
--

CREATE TABLE `magazines` (
  `id` int(10) UNSIGNED NOT NULL,
  `Type` varchar(40) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Date_Of_Receipt` date DEFAULT NULL,
  `Date_Published` date DEFAULT NULL,
  `Pages` int(11) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT 0.00,
  `Publisher` varchar(140) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `magazines`
--

INSERT INTO `magazines` (`id`, `Type`, `Name`, `Date_Of_Receipt`, `Date_Published`, `Pages`, `Price`, `Publisher`) VALUES
(1, 'Craft & Hobbies Magazines', 'Birds & Blooms Extra', '2020-02-04', '2020-02-05', NULL, '0.00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--

CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_grouppermissions`
--

INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 2, 'books', 1, 3, 3, 3),
(2, 2, 'NewsPapers', 1, 3, 3, 3),
(3, 2, 'Magazines', 1, 3, 3, 3),
(4, 2, 'Users', 1, 3, 3, 3),
(5, 2, 'Book_Issue', 1, 3, 3, 3),
(6, 2, 'Return_Book', 1, 3, 3, 3),
(7, 2, 'Types', 1, 3, 3, 3),
(8, 2, 'Return', 1, 3, 3, 3),
(30, 3, 'books', 0, 3, 0, 0),
(31, 3, 'NewsPapers', 0, 3, 0, 0),
(32, 3, 'Magazines', 0, 3, 0, 0),
(33, 3, 'Users', 0, 3, 0, 0),
(34, 3, 'Book_Issue', 0, 3, 0, 0),
(35, 3, 'Return_Book', 0, 3, 0, 0),
(36, 3, 'Types', 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--

CREATE TABLE `membership_groups` (
  `groupID` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_groups`
--

INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES
(1, 'anonymous', 'Anonymous group created automatically on 2020-09-10', 0, 0),
(2, 'Admins', 'Admin group created automatically on 2020-09-10', 0, 1),
(3, 'demo', 'demo users', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--

CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT 0,
  `allowEdit` tinyint(4) NOT NULL DEFAULT 0,
  `allowDelete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--

CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) UNSIGNED NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) UNSIGNED DEFAULT NULL,
  `dateUpdated` bigint(20) UNSIGNED DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_userrecords`
--

INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES
(16, 'Users', '3', 'admin', 1603904947, 1603904991, 2),
(19, 'Users', '4', 'admin', 1604033048, 1604033057, 2),
(20, 'Users', '5', 'iqramul', 1604201342, 1604201355, 2),
(21, 'Users', '6', 'iqramul', 1604201396, 1604201396, 2),
(22, 'Users', '7', 'iqramul', 1604201469, 1604201469, 2),
(23, 'Users', '8', 'iqramul', 1604201506, 1604201506, 2),
(24, 'Users', '9', 'iqramul', 1604201537, 1604201537, 2),
(25, 'Users', '10', 'iqramul', 1604201562, 1604201562, 2),
(26, 'Users', '11', 'iqramul', 1604201603, 1604201603, 2),
(27, 'Users', '12', 'iqramul', 1604201741, 1604201741, 2),
(28, 'Types', '5', 'iqramul', 1604201830, 1604201830, 2),
(29, 'books', '5', 'iqramul', 1604202122, 1604202122, 2),
(30, 'books', '6', 'iqramul', 1604202225, 1604202225, 2),
(31, 'books', '7', 'iqramul', 1604202336, 1604202336, 2),
(32, 'books', '8', 'iqramul', 1604202412, 1604202412, 2),
(33, 'books', '9', 'iqramul', 1604202499, 1604202499, 2),
(34, 'books', '10', 'iqramul', 1604202602, 1604202602, 2),
(35, 'Types', '6', 'iqramul', 1604202778, 1604202778, 2),
(36, 'books', '11', 'iqramul', 1604202825, 1604202825, 2),
(37, 'books', '12', 'iqramul', 1604202910, 1604202910, 2),
(38, 'books', '13', 'iqramul', 1604203006, 1604203006, 2),
(39, 'Types', '7', 'iqramul', 1604203205, 1604203205, 2),
(40, 'books', '14', 'iqramul', 1604203322, 1604203322, 2),
(41, 'books', '15', 'iqramul', 1604203388, 1604203388, 2),
(42, 'books', '16', 'iqramul', 1604203449, 1604203449, 2),
(43, 'Types', '8', 'iqramul', 1604203545, 1604203545, 2),
(44, 'books', '17', 'iqramul', 1604203574, 1604203574, 2),
(45, 'books', '18', 'iqramul', 1604203620, 1604203620, 2),
(46, 'Types', '9', 'iqramul', 1604203748, 1604203748, 2),
(47, 'books', '19', 'iqramul', 1604203768, 1604203768, 2),
(48, 'books', '20', 'iqramul', 1604203804, 1604203804, 2),
(49, 'Book_Issue', '3', 'iqramul', 1604203865, 1604250016, 2),
(50, 'Book_Issue', '4', 'iqramul', 1604203929, 1604203929, 2),
(51, 'NewsPapers', '2', 'iqramul', 1604204017, 1604204017, 2),
(52, 'Magazines', '1', 'iqramul', 1604204159, 1604204159, 2),
(53, 'Book_Issue', '5', 'keshob', 1604204547, 1604204547, 2),
(54, 'Book_Issue', '6', 'keshob', 1604205422, 1604251405, 2),
(57, 'Book_Issue', '7', 'iqramul', 1604249974, 1604249991, 2),
(58, 'Users', '13', 'iqramul', 1604251052, 1604251052, 2),
(59, 'Book_Issue', '8', 'iqramul', 1604251169, 1604251169, 2),
(60, 'books', '22', 'iqramul', 1604251298, 1604251298, 2),
(61, 'Book_Issue', '9', 'iqramul', 1604251359, 1604251359, 2),
(62, 'Users', '14', 'iqramul', 1604251886, 1604251908, 2),
(63, 'Users', '15', 'iqramul', 1604252209, 1604252209, 2),
(64, 'Types', '11', 'iqramul', 1604252297, 1604252300, 2),
(65, 'books', '23', 'iqramul', 1604252318, 1604252318, 2),
(66, 'Book_Issue', '10', 'iqramul', 1604252407, 1604252429, 2);

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--

CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) UNSIGNED DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text DEFAULT NULL,
  `custom2` text DEFAULT NULL,
  `custom3` text DEFAULT NULL,
  `custom4` text DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_users`
--

INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES
('demo', 'b95b5fdacd1ddb6e9d49619af71dc774', 'demo@demo.com', '2020-09-10', 3, 0, 1, 'demo user', 'demo', 'demo', 'demo', 'demo\nmember changed his password on 11/01/2020, 12:42 pm from IP address ::1', NULL, NULL),
('guest', NULL, NULL, '2018-02-24', 1, 0, 1, NULL, NULL, NULL, NULL, 'Anonymous member created automatically on 2018-02-24', NULL, NULL),
('iqramul', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', '2020-09-10', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-02-24', NULL, NULL),
('iqramul hasan', '02d62574863469f4f1ef99d8fc453a31', 'admin@admin.com', '2020-11-01', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2020-11-01', NULL, NULL),
('keshob', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', '2020-09-10', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-02-24', NULL, NULL),
('test', '098f6bcd4621d373cade4e832627b4f6', 'test@demo.com', '2020-09-10', 3, 0, 1, 'test user', 'test', 'test', 'test', 'test\nmember changed his password on 11/01/2020, 04:23 am from IP address ::1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `newspapers`
--

CREATE TABLE `newspapers` (
  `id` int(10) UNSIGNED NOT NULL,
  `Language` varchar(40) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Date_Of_Receipt` date DEFAULT NULL,
  `Date_Published` date DEFAULT NULL,
  `Pages` int(11) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT 0.00,
  `Type` varchar(40) DEFAULT NULL,
  `Publisher` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newspapers`
--

INSERT INTO `newspapers` (`id`, `Language`, `Name`, `Date_Of_Receipt`, `Date_Published`, `Pages`, `Price`, `Type`, `Publisher`) VALUES
(2, 'Bangla', 'প্রথম আলো', '2020-01-01', '2020-01-01', NULL, '0.00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `return_book`
--

CREATE TABLE `return_book` (
  `id` int(10) UNSIGNED NOT NULL,
  `Book_Number` int(10) UNSIGNED DEFAULT NULL,
  `Book_Title` int(10) UNSIGNED DEFAULT NULL,
  `Issue_Date` date DEFAULT NULL,
  `Due_Date` int(10) UNSIGNED DEFAULT 1,
  `Return_Date` date DEFAULT NULL,
  `Member` int(10) UNSIGNED DEFAULT NULL,
  `Number` int(10) UNSIGNED DEFAULT NULL,
  `Fine` decimal(10,2) DEFAULT 0.00,
  `Status` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `Name`) VALUES
(5, 'CSE'),
(6, 'LLB'),
(7, 'English'),
(8, 'English Novel'),
(9, 'Humayun Ahmed Novel'),
(11, 'EEE');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `Membership_Number` varchar(40) DEFAULT NULL,
  `Name` varchar(140) DEFAULT NULL,
  `Contact` varchar(40) DEFAULT NULL,
  `ID_Number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Membership_Number`, `Name`, `Contact`, `ID_Number`) VALUES
(3, 'STD003', 'Iqramul', '01792567505', 162112006),
(4, 'STD004', 'Hasnat', '01792567505', 162112007),
(5, 'STD001', 'Rubel', '01456789542', 162112001),
(6, 'STD002', 'Rasel', '01456789541', 162112002),
(7, 'STD005', 'Naim', '01792567506', 162112005),
(8, 'STD006', 'Shahin', '01927866737', 162112006),
(9, 'STD007', 'Piton', '01927866738', 162112007),
(10, 'STD008', 'Suprojit', '01927866745', 162112008),
(11, 'STD009', 'Wahid', '01792567454', 162112009),
(12, 'STD010', 'Nitesh', '01792567466', 162112010),
(13, 'STD013', 'Iqbal', '01786653667', 162112031),
(14, 'STD014', 'Hasan', '01927866737', 162112030),
(15, 'STD015', 'Masum', '01927866773', 162112028);

-- --------------------------------------------------------

--
-- Structure for view `iqramul`
--
DROP TABLE IF EXISTS `iqramul`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `iqramul`  AS SELECT `membership_users`.`memberID` AS `memberID`, `membership_users`.`passMD5` AS `passMD5`, `membership_users`.`email` AS `email`, `membership_users`.`signupDate` AS `signupDate`, `membership_users`.`groupID` AS `groupID`, `membership_users`.`isBanned` AS `isBanned`, `membership_users`.`isApproved` AS `isApproved`, `membership_users`.`custom1` AS `custom1`, `membership_users`.`custom2` AS `custom2`, `membership_users`.`custom3` AS `custom3`, `membership_users`.`custom4` AS `custom4`, `membership_users`.`comments` AS `comments`, `membership_users`.`pass_reset_key` AS `pass_reset_key`, `membership_users`.`pass_reset_expiry` AS `pass_reset_expiry` FROM `membership_users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Book_Type` (`Book_Type`);

--
-- Indexes for table `book_issue`
--
ALTER TABLE `book_issue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Member` (`Member`),
  ADD KEY `Book_Number` (`Book_Number`);

--
-- Indexes for table `magazines`
--
ALTER TABLE `magazines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_groups`
--
ALTER TABLE `membership_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Indexes for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  ADD PRIMARY KEY (`recID`),
  ADD UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`),
  ADD KEY `pkValue` (`pkValue`),
  ADD KEY `tableName` (`tableName`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `membership_users`
--
ALTER TABLE `membership_users`
  ADD PRIMARY KEY (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `newspapers`
--
ALTER TABLE `newspapers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_book`
--
ALTER TABLE `return_book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Book_Number` (`Book_Number`),
  ADD KEY `Member` (`Member`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `book_issue`
--
ALTER TABLE `book_issue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `magazines`
--
ALTER TABLE `magazines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `membership_groups`
--
ALTER TABLE `membership_groups`
  MODIFY `groupID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  MODIFY `recID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `newspapers`
--
ALTER TABLE `newspapers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `return_book`
--
ALTER TABLE `return_book`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
