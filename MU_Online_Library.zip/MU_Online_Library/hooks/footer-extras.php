<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0.1
    </div>
    <strong>&copy <a href="http://metrouni.edu.bd/">Metropolitan University, Sylhet.</a></strong>
  </footer>
